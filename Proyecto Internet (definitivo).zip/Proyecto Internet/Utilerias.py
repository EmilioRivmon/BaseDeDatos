import pymysql as my

def pide_entero(li,ls,let):
    x=li-1
    while x<li or x>ls:
        x=int(input(let))
        if x<li or x>ls:
            print("Error, fuera de rango entre",li,"y",ls)
            input()
    return x


def pide_flotante(li,ls,let):
    x=li-1
    while x<li or x>ls:
        x=float(input(let))
        if x<li or x>ls:
            print("Error, fuera de rango entre",li,"y",ls)
            input()
    return x

def pausa():
    input("Presione Enter para continuar...")

def error(Let):
    print(Let)
    print("Oprima [ENTER] para continuar...")
    input()

def pide_cadena(li,ls,let):
    long_cad=-1
    while long_cad<li or long_cad>ls:
        cad=input(let)
        long_cad=len(cad)
        if long_cad<li or long_cad>ls:
            print("Error, longitud de cadena entre",li,"y",ls,"caracteres...")
            input()
    return cad

def limpia_pantalla():
    for i in range(45):
        print()

#Para conectarse a una base de datos (en sep 2021, una base de MySQL)
def conectar_bd():
    cone_bd=my.connect(host="localhost",
                       user="root",
                       passwd="",
                       database="proyecto_base_de_datos")
    return cone_bd