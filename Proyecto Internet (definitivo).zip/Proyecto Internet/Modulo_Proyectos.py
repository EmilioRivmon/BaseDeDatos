#Módulo de Proyectos
import Utilerias as my

def alta_proyectos():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Altas de Proyectos            |")
    print("|-------------------------------|")
    vnum=my.pide_cadena(5,5,"Indica el Numero del proyecto                             : ")
    vnum=vnum.upper()
    vnom=my.pide_cadena(1,15,"Indica el Nombre del proyecto                            : ")
    var=my.pide_cadena(1,15,"Indica el Area del proyecto                               : ")
    vdes=my.pide_cadena(1,200,"Indica la descripcion del proyecto                      : ")
    vcien=my.pide_cadena(1,5,"Indica el Id del Cientifico que esta asignado al proyecto: ")
    vcien=vcien.upper()
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor() #Permite hacer operación en la base de datos, llamar igual que la función
    query="INSERT INTO proyectos VALUES('"+vnum+"','"+vnom+"','"+var+"','"+vdes+"','"+vcien+"')"
    #print(query)
    seguro=my.pide_cadena(1,1,"Los datos son correctos, ¿desea grabar? [S/N]: ")
    seguro=seguro.upper()
    if seguro=="S":
        try:
            x=cursor.execute(query)#Si se ejecuta bien, devuelve 1
        except:
            x=0
        if x==0:
            my.error("El Id del Cientifico se duplica en el archivo de proyectos")
        else:
            my.error("Los datos han sido grabados correctamente")
    else:
        my.error("La acción de grabar ha sido cancelada")
    cone_bd.commit()
    cone_bd.close()

def baja_proyectos():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Bajas de Proyectos            |")
    print("|-------------------------------|")
    vnum=my.pide_cadena(5,5,"Indica el id del proyectos a eliminar: ")
    vnum=vnum.upper()
    query="DELETE FROM proyectos WHERE id_pro='"+vnum+"'"
    seguro=my.pide_cadena(1,1,"Seguro de eliminar [S/N]: ")
    seguro=seguro.upper()
    if seguro=="S":
        cone_bd=my.conectar_bd()
        cursor=cone_bd.cursor()
        x=cursor.execute(query)
        if x==0:
            my.error("Id inexistente en el archivo de proyectos")
        else:
            my.error("El registro ha sido eliminado correctamente")
        cone_bd.commit()
        cone_bd.close()
    else:
        my.error("La acción de eliminar ha sido cancelada")


def consulta_proyectos():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Consultas de Proyectos        |")
    print("|-------------------------------|")
    vnum=my.pide_cadena(5,5,"Indica el id del proyectos: ")
    vnum=vnum.upper()
    query="SELECT * FROM proyectos WHERE id_pro='"+vnum+"'"
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    if x==0:
        my.error("Id inexistente en el archivo de proyectos")
    else:
        datos_proyecto=cursor.fetchone()
        print("Nombre            : ",datos_proyecto[1])
        print("Area              : ",datos_proyecto[2])
        print("Descripcion       : ",datos_proyecto[3])
        print("Id del cientifico : ",datos_proyecto[4])
        my.error("")
    cone_bd.close()

def cambios_telefono():
    my.limpia_pantalla()
    print("|-----------------------------------------------------|")
    print("| Cambio de id del Cientifico asignado al Proyecto    |")
    print("|-----------------------------------------------------|")
    vnum=my.pide_cadena(5,5,"Indica el Id del cientifico    : ")
    vnum=vnum.upper()
    vcien=my.pide_cadena(1,5,"Indica el nuevo Id del cientifico: ")
    vcien=vcien.upper()
    query="UPDATE proyectos SET Id_ci_pro='"+vcien+"' WHERE id_pro='"+vnum+"'"
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    if x==0:
        my.error("Id inexistente en el archivo de proyectos")
    else:
        my.error("El cambio ha sido realizado exitosamente")
    cone_bd.commit()
    cone_bd.close()

def menu_proyecto():
    op=-1
    while op!=0:
        my.limpia_pantalla()
        print("|-------------------------------|")
        print("| MENU DE PROYECTO              |")
        print("|-------------------------------|")
        print("| 1) Altas de Proyectos         |")
        print("| 2) Bajas de Proyectos         |")
        print("| 3) Consulta de Proyectos      |")
        print("| 4) Cambio de Id               |")
        print("| 0) Regresar al menú principal |")
        print("|-------------------------------|")
        op=my.pide_entero(0,4,"Indica la opción deseada: ")
        if op==1:
            alta_proyectos()
        if op==2:
            baja_proyectos()
        if op==3:
            consulta_proyectos()
        if op==4:
            cambios_telefono()
        my.limpia_pantalla()