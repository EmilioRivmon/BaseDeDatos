#Módulo de cientificos
import Utilerias as my

def valida_id():
    global vid
    valido=False
    while(valido==False):
        vid=my.pide_cadena(5,5,"Indica el ID del científico               : ")
        if(vid.isdigit()==False):
            my.error("ERROR, el ID solo puede contener números...")
        else:
            valido=True

def valida_tel():
    global vtel
    valido=False
    while(valido==False):
        vtel=my.pide_cadena(10,10,"Indica el número telefónico del científico: ")
        if(vtel.isdigit()==False):
            my.error("ERROR, el teléfono solo puede contener números...")
        else:
            valido=True

def valida_cor():
    global vcor
    valido=False
    while(valido==False):
        vcor=my.pide_cadena(3,30,"Indica el correo del científico           : ")
        if(vcor.count('@')==0):
             my.error("ERROR, el correo no tiene el @...")
        else:
            valido=True

def alta_cientifico():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Altas de científicos          |")
    print("|-------------------------------|")
    #Validar que el ID contenga solo números
    valida_id()
    vnom=my.pide_cadena(1,15,"Indica el nombre del científico           : ")
    vap=my.pide_cadena(1,15, "Indica el Ap. Paterno del científico      : ")
    vam=my.pide_cadena(1,15, "Indica el Ap. Materno del científico      : ")
    #Validar que el teléfono contenga solo números
    valida_tel()     
    #Validar que el correo contenga al @
    valida_cor()
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor() #Permite hacer operación en la base de datos, llamar igual que la función
    query="INSERT INTO cientificos VALUES('"+vid+"','"+vnom+"','"+vap+"','"+vam+"','"+vtel+"','"+vcor+"')"
    #print(query)
    seguro=my.pide_cadena(1,1,"Los datos son correctos, ¿desea grabar? [S/N]: ")
    seguro=seguro.upper()
    if seguro=="S":
        try:
            x=cursor.execute(query)#Si se ejecuta bien, devuelve 1
        except:
            x=0
        if x==0:
            my.error("ERROR, el ID se duplica en el archivo de científicos...")
        else:
            my.error("Los datos han sido grabados correctamente")
    else:
        my.error("La acción de grabar ha sido cancelada")
    cone_bd.commit()
    cone_bd.close()

def baja_cientifico():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Bajas de científicos          |")
    print("|-------------------------------|")
    #Validar que el ID contenga solo números
    valida_id()
    query="SELECT * FROM proyectos WHERE Id_ci_pro='"+vid+"'"
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    if x==1:
        my.error("ERROR, el científico a eliminar tiene un proyecto a cargo, transfiere el proyecto a otro científico...")
    else:
        query="DELETE FROM cientificos WHERE Id_ci='"+vid+"'"
        seguro=my.pide_cadena(1,1,"Seguro de eliminar [S/N]: ")
        seguro=seguro.upper()
        if seguro=="S":
            x=cursor.execute(query)
            if x==0:
                my.error("ERROR, ID inexistente en el archivo de cientificos...")
            else:
                my.error("El registro ha sido eliminado correctamente")
        else:
            my.error("La acción de eliminar ha sido cancelada")
    cone_bd.commit()
    cone_bd.close()


def consulta_cientifico():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Consultas de Científicos      |")
    print("|-------------------------------|")
    #Validar que el ID contenga solo números
    valida_id()
    query="SELECT * FROM cientificos WHERE Id_ci='"+vid+"'"
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    if x==0:
        my.error("ERROR, ID inexistente en el archivo de científicos...")
    else:
        datos_cientifico=cursor.fetchone()
        print("Nombre            : ",datos_cientifico[1])
        print("Ap. paterno       : ",datos_cientifico[2])
        print("Ap. materno       : ",datos_cientifico[3])
        print("Número teléfonico : ",datos_cientifico[4])
        print("Correo            : ",datos_cientifico[5])
        my.error("")
    cone_bd.close()

def cambios_cientifico():##Cambios importantes
    my.limpia_pantalla()
    op=-1;
    print("|-----------------------------------|")
    print("| Cambios de científicos            |")
    print("|-----------------------------------|")
    print("| 1) Cambio de teléfono             |")
    print("| 2) Cambio de correo               |")
    print("| 0) Regresar al menú de científicos|")
    print("|-----------------------------------|")
    op=my.pide_entero(0,2,"Indica la opción deseada: ")
    if (op==0):
        pass;
    
    if (op==1):
        valida_id()
        valida_tel()
        query="UPDATE cientificos SET tel_ci='"+vtel+"' WHERE Id_ci='"+vid+"'"
        cone_bd=my.conectar_bd()
        cursor=cone_bd.cursor()
        x=cursor.execute(query)
        if x==0:
            my.error("ERROR, ID inexistente en el archivo de científicos...")
        else:
            my.error("El cambio de teléfono ha sido realizado exitosamente")
        cone_bd.commit()
        cone_bd.close()
        
    if (op==2):
        valida_id()
        valida_cor()#Mismo problema con mostrar "Indica el nuevo correo del científico"
        query="UPDATE cientificos SET correo_ci='"+vcor+"' WHERE Id_ci='"+vid+"'"
        cone_bd=my.conectar_bd()
        cursor=cone_bd.cursor()
        x=cursor.execute(query)
        if x==0:
            my.error("ERROR, ID inexistente en el archivo de científicos...")
        else:
            my.error("El cambio de correo ha sido realizado exitosamente")
        cone_bd.commit()
        cone_bd.close()      

def menu_cientifico():
    op=-1
    while op!=0:
        my.limpia_pantalla()
        print("|-------------------------------|")
        print("| MENÚ DE CIENTÍFICOS           |")
        print("|-------------------------------|")
        print("| 1) Altas de científicos       |")
        print("| 2) Bajas de científicos       |")
        print("| 3) Consulta de científicos    |")
        print("| 4) Cambios de científicos     |")
        print("| 0) Regresar al menú principal |")
        print("|-------------------------------|")
        op=my.pide_entero(0,4,"Indica la opción deseada: ")
        if op==1:
            alta_cientifico()
        if op==2:
            baja_cientifico()
        if op==3:
            consulta_cientifico()
        if op==4:
            cambios_cientifico()
        my.limpia_pantalla()
