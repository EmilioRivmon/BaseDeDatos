#Módulo de Proyectos
import Utilerias as my

def valida_num():
    global vnum
    valido=False
    while(valido==False):
        vnum=my.pide_cadena(5,5,  "Indica el número del proyecto                             : ")
        if(vnum.isdigit()==False):
            my.error("ERROR, el número del proyecto solo puede contener números...")
        else:
            valido=True

def valida_id():
    global vcien
    valido=False
    while(valido==False):
        vcien=my.pide_cadena(5,5, "Indica el ID del científico que está asignado al proyecto : ")          
        if(vcien.isdigit()==False):
            my.error("ERROR, el ID solo puede contener números...")
        else:
            valido=True

def alta_proyectos():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Altas de proyectos            |")
    print("|-------------------------------|")
    #Validar que el num. de proyecto contenga solo números
    valida_num()
    vnom=my.pide_cadena(1,15, "Indica el nombre del proyecto                             : ")                     
    var=my.pide_cadena(1,15,  "Indica el área del proyecto                               : ")
    vdes=my.pide_cadena(1,200,"Indica la descripción del proyecto                        : ")
    valida_id()
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()#Permite hacer operación en la base de datos, llamar igual que la función
    query="SELECT * FROM cientificos WHERE id_ci='"+vcien+"'"
    x=cursor.execute(query)
    if (vcien==vnum):
        my.error("ERROR, el número del proyecto no puede ser nombrado igual que el número del científico...")
    else:
        if x==0:
            my.error("ERROR, ID del científico inexistente en el archivo de científicos...")
        else:
            query="INSERT INTO proyectos VALUES('"+vnum+"','"+vnom+"','"+var+"','"+vdes+"','"+vcien+"')"
            seguro=my.pide_cadena(1,1,"Los datos son correctos, ¿desea grabar? [S/N]: ")
            seguro=seguro.upper()
            if seguro=="S":
                try:
                    x=cursor.execute(query)#Si se ejecuta bien, devuelve 1
                except:
                    x=0
                if x==0:
                    my.error("ERROR, el ID del proyecto se duplica en el archivo de proyectos...")
                else:
                    my.error("Los datos han sido grabados correctamente")
            else:
                my.error("La acción de grabar ha sido cancelada")
        cone_bd.commit()
        cone_bd.close()

def baja_proyectos():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Bajas de proyectos            |")
    print("|-------------------------------|")
    valida_num()
    query="DELETE FROM proyectos WHERE id_pro='"+vnum+"'"
    seguro=my.pide_cadena(1,1,"Seguro de eliminar [S/N]: ")
    seguro=seguro.upper()
    if seguro=="S":
        cone_bd=my.conectar_bd()
        cursor=cone_bd.cursor()
        x=cursor.execute(query)
        if x==0:
            my.error("ERROR, ID del proyecto inexistente en el archivo de proyectos...")
        else:
            my.error("El registro ha sido eliminado correctamente")
        cone_bd.commit()
        cone_bd.close()
    else:
        my.error("La acción de eliminar ha sido cancelada")


def consulta_proyectos():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Consultas de proyectos        |")
    print("|-------------------------------|")
    valida_num()
    query="SELECT * FROM proyectos WHERE id_pro='"+vnum+"'"
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    if x==0:
        my.error("ERROR, ID del proyecto inexistente en el archivo de proyectos...")
    else:
        datos_proyecto=cursor.fetchone()
        print("Nombre            : ",datos_proyecto[1])
        print("Área              : ",datos_proyecto[2])
        print("Descripción       : ",datos_proyecto[3])
        print("ID del científico : ",datos_proyecto[4])
        my.error("")
    cone_bd.close()

def cambio_proyecto():
    my.limpia_pantalla()
    print("|-----------------------------------------------------|")
    print("| Cambio del científico asignado al proyecto          |")
    print("|-----------------------------------------------------|")
    valida_num()
    #Validar ID del científico solo contenga números
    valido=False
    while(valido==False):
        vcien=my.pide_cadena(5,5,"Indica el nuevo ID del científico                        : ")
        if(vcien.isdigit()==False):
            my.error("ERROR, el ID solo puede contener números...")
        else:
            valido=True
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    query="SELECT * FROM cientificos WHERE Id_ci='"+vcien+"'"
    x=cursor.execute(query)
    if x==0:
        my.error("ERROR, ID del científico inexistente en el archivo de cientificos...")
    else:
        query="UPDATE proyectos SET Id_ci_pro='"+vcien+"' WHERE id_pro='"+vnum+"'"
        x=cursor.execute(query)
        if x==0:
            my.error("ERROR, ID del proyecto inexistente en el archivo de proyectos...")
        else:
            my.error("El cambio ha sido realizado exitosamente")
    cone_bd.commit()
    cone_bd.close()

def menu_proyecto():
    op=-1
    while op!=0:
        my.limpia_pantalla()
        print("|-------------------------------|")
        print("| MENÚ DE PROYECTOS             |")
        print("|-------------------------------|")
        print("| 1) Altas de proyectos         |")
        print("| 2) Bajas de proyectos         |")
        print("| 3) Consulta de proyectos      |")
        print("| 4) Cambios de proyectos       |")
        print("| 0) Regresar al menú principal |")
        print("|-------------------------------|")
        op=my.pide_entero(0,4,"Indica la opción deseada: ")
        if op==1:
            alta_proyectos()
        if op==2:
            baja_proyectos()
        if op==3:
            consulta_proyectos()
        if op==4:
            cambio_proyecto()
        my.limpia_pantalla()
