def espa(posiciones,elementos):
    x=(posiciones-len(elementos))*" "
    return x
n="Python"
value = n
print(value[1:3])
