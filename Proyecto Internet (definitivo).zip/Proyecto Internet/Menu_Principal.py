# A01367816 Carlos Emilio Murillo Millan
# A01770428 Brandon Abraham Becerril Hernández
# A01368205 Emilio Jacob Rivas Monroy
import Utilerias as my
import Modulo_Cientificos as ci
import Modulo_Proyectos as py
import Modulo_Reportes as rp

def menu_principal():
    op=-1
    while op!=0:
        my.limpia_pantalla()
        print("|----------------------|")
        print("| MENU PRINCIPAL       |")
        print("|----------------------|")
        print("| 1) Cientificos       |")
        print("| 2) Proyectos         |")
        print("| 3) Reportes          |")
        print("| 0) Salir del Sistema |")
        print("|----------------------|")
        op=my.pide_entero(0,3,"Indica la opción deseada: ")
        if op==1:
            ci.menu_cientifico()
        if op==2:
            py.menu_proyecto()
        if op==3:
            rp.modulo_reportes()
        my.limpia_pantalla()
        
#Menu principal
menu_principal()