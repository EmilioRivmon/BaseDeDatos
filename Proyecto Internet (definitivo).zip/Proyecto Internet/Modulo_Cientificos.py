#Módulo de cientificos
import Utilerias as my

def alta_cientifico():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Altas de Cientificos          |")
    print("|-------------------------------|")
    vid=my.pide_cadena(5,5,"Indica el id del cientifico                 : ")
    vid=vid.upper()
    vnom=my.pide_cadena(1,15,"Indica el nombre del cientifico           : ")
    vap=my.pide_cadena(1,15,"Indica el Ap. Paterno del cientifico       : ")
    vam=my.pide_cadena(1,15,"Indica el Ap. Materno del cientifico       : ")
    vtel=my.pide_cadena(1,10,"Indica el numero telefonico del cientifico: ")
    vcor=my.pide_cadena(1,30,"Indica el correo del cientifico           : ")
    vtel=vtel.upper()
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor() #Permite hacer operación en la base de datos, llamar igual que la función
    query="INSERT INTO cientificos VALUES('"+vid+"','"+vnom+"','"+vap+"','"+vam+"','"+vtel+"','"+vcor+"')"
    #print(query)
    seguro=my.pide_cadena(1,1,"Los datos son correctos, ¿desea grabar? [S/N]: ")
    seguro=seguro.upper()
    if seguro=="S":
        try:
            x=cursor.execute(query)#Si se ejecuta bien, devuelve 1
        except:
            x=0
        if x==0:
            my.error("El telefono se duplica en el archivo de cientificos")
        else:
            my.error("Los datos han sido grabados correctamente")
    else:
        my.error("La acción de grabar ha sido cancelada")
    cone_bd.commit()
    cone_bd.close()

def baja_cientifico():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Bajas de Cientificos          |")
    print("|-------------------------------|")
    vid=my.pide_cadena(5,5,"Indica el id del cientificos a eliminar: ")
    vid=vid.upper()
    query="DELETE FROM cientificos WHERE Id_ci='"+vid+"'"
    seguro=my.pide_cadena(1,1,"Seguro de eliminar [S/N]: ")
    seguro=seguro.upper()
    if seguro=="S":
        cone_bd=my.conectar_bd()
        cursor=cone_bd.cursor()
        x=cursor.execute(query)
        if x==0:
            my.error("Id inexistente en el archivo de cientificos")
        else:
            my.error("El registro ha sido eliminado correctamente")
        cone_bd.commit()
        cone_bd.close()
    else:
        my.error("La acción de eliminar ha sido cancelada")


def consulta_cientifico():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Consultas de Cientificos      |")
    print("|-------------------------------|")
    vid=my.pide_cadena(5,5,"Indica el id del cientifico: ")
    vid=vid.upper()
    query="SELECT * FROM cientificos WHERE Id_ci='"+vid+"'"
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    if x==0:
        my.error("Id inexistente en el archivo de cientificos")
    else:
        datos_cientifico=cursor.fetchone()
        print("Nombre            : ",datos_cientifico[1])
        print("Ap. Paterno       : ",datos_cientifico[2])
        print("Ap. Materno       : ",datos_cientifico[3])
        print("Numero Telefonico : ",datos_cientifico[4])
        print("Correo            : ",datos_cientifico[5])
        my.error("")
    cone_bd.close()

def cambios_telefono():
    my.limpia_pantalla()
    print("|-------------------------------|")
    print("| Cambio de Telefono           |")
    print("|-------------------------------|")
    vid=my.pide_cadena(5,5,"Indica el Id del cientifico    : ")
    vid=vid.upper()
    vtel=my.pide_cadena(1,10,"Indica el nuevo telefono del cientifico: ")
    vtel=vtel.upper()
    query="UPDATE cientificos SET tel_ci='"+vtel+"' WHERE Id_ci='"+vid+"'"
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    if x==0:
        my.error("Id inexistente en el archivo de cientificos")
    else:
        my.error("El cambio ha sido realizado exitosamente")
    cone_bd.commit()
    cone_bd.close()

def menu_cientifico():
    op=-1
    while op!=0:
        my.limpia_pantalla()
        print("|-------------------------------|")
        print("| MENU DE CIENTIFICOS           |")
        print("|-------------------------------|")
        print("| 1) Altas de Cientificos       |")
        print("| 2) Bajas de Cientificos       |")
        print("| 3) Consulta de Cientificos    |")
        print("| 4) Cambio de Telefono         |")
        print("| 0) Regresar al menú principal |")
        print("|-------------------------------|")
        op=my.pide_entero(0,4,"Indica la opción deseada: ")
        if op==1:
            alta_cientifico()
        if op==2:
            baja_cientifico()
        if op==3:
            consulta_cientifico()
        if op==4:
            cambios_telefono()
        my.limpia_pantalla()