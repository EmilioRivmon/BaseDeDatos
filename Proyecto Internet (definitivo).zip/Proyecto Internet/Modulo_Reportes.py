import Utilerias as my

def espa(posiciones,elementos):
    x=(posiciones-len(elementos))*" "
    return x

def valida_num():
    global vnum
    valido=False
    while(valido==False):
        vnum=my.pide_cadena(5,5,"Indica el número del científico                            : ")
        if(vnum.isdigit()==False):
            my.error("ERROR, el ID del científico solo puede contener números...")
        else:
            valido=True


def lista_cientificos():
    query="SELECT * FROM cientificos ORDER BY nombre_ci"
    my.limpia_pantalla()
    print("----------------------------------------------------------------------------------------------------")
    print("---------------------------------LISTADO DE CIENTIFÍCO----------------------------------------------")
    print("----------------------------------------------------------------------------------------------------")
    print("ID    Nombre           Ap. Paterno      Ap. Materno      Telefono    Correo                         ") 
    print("----------------------------------------------------------------------------------------------------")
          #12345 123456789012345  123456789012345  123456789012345  1234567890  123456789012345678901234567890
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    lista=cursor.fetchall()
    for reg in lista:
        print(reg[0]+" "+reg[1]+espa(17,reg[1])+reg[2]+espa(17,reg[2])+reg[3]+espa(17,reg[3])+reg[4]+espa(12,reg[4])+reg[5])
    my.error("")
    cone_bd.close()

def lista_proyectos():
    desc = 3
    query="SELECT * FROM proyectos ORDER BY id_pro"
    my.limpia_pantalla()

    print("---------------------------------------------------------------------------------------------------------------------------")
    print("-----------------------------------------------------------LISTADO DE PROYECTOS--------------------------------------------")
    print("---------------------------------------------------------------------------------------------------------------------------")  
    
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    lista=cursor.fetchall()
    n = 40
    for reg in lista:
        print("ID del proyecto: {} ||| Nombre: {} ||| Área: {} ||| Id Científico: {}".format(reg[0], reg[1], reg[2], reg[4]))
        #print("Descripcion: {}".format(reg[desc]))
        print("Descripcion:")
        chunks = [reg[desc][i:i+n] for i in range(0, len(reg[desc]), n)]
        #print(chunks)
        for ndesc in chunks:
            print('{:^40}'.format(ndesc))
        print("---------------------------------------------------------------------------------------------------------------------------")
        #print(reg[0]+" "+reg[1]+espa(17,reg[1])+reg[2]+espa(17,reg[2])+reg[3]+espa(42,reg[3])+reg[4]+espa(12,reg[4]))
    my.error("")
    cone_bd.close()
    print(reg)
    
def lista_proyectos_area():
    desc = 3
    my.limpia_pantalla()
    var=my.pide_cadena(1,15,"Indica el área : ")
    var=var.upper()
    query="SELECT * FROM proyectos WHERE area_pro='"+var+"'"
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    if x==0:
        my.error("Error, área inexistente en archivo de proyectos...")
    else:

        # ID NomnbreProyecto Area Descripción
        query="SELECT id_pro, nombre_pro, area_pro, descripcion_pro, id_ci_pro"
        query+=" FROM proyectos"
        query+=" WHERE area_pro='"+var+"'"
        cursor.execute(query)
        lista=cursor.fetchall()
        n = 40
        for reg in lista:
            print("ID del proyecto: {} ||| Nombre: {} ||| Área: {} ||| Id Científico: {}".format(reg[0], reg[1], reg[2], reg[4]))
            #print("Descripcion: {}".format(reg[desc]))
            print("Descripcion:")
            chunks = [reg[desc][i:i+n] for i in range(0, len(reg[desc]), n)]
            #print(chunks)
            for ndesc in chunks:
                print('{:^40}'.format(ndesc))
            print("---------------------------------------------------------------------------------------------------------------------------")
            #print(reg[0]+" "+reg[1]+espa(17,reg[1])+reg[2]+espa(17,reg[2])+reg[3]+espa(42,reg[3])+reg[4]+espa(12,reg[4]))
        my.error("")
        cone_bd.close()
        print(reg)

def lista_cientificos_area():
    my.limpia_pantalla()
    var=my.pide_cadena(1,15,"Indica el área : ")
    var=var.upper()
    query="SELECT * FROM proyectos WHERE area_pro='"+var+"'"
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    if x==0:
        my.error("Error, área inexistente en archivo de proyectos...")
    else:
        datos_area=cursor.fetchone()
        print(" "*60,"Área del proyecto : ",datos_area[2])
        query="SELECT id_ci, nombre_ci, ap_ci, am_ci, tel_ci, correo_ci"
        query+=" FROM proyectos, cientificos"
        query+=" WHERE id_ci=id_ci_pro and area_pro='"+var+"'"
        cursor.execute(query)
        lista=cursor.fetchall()
        print("-----------------------------------------------------------------------------------------------------")
        print("-------------------------------------------LISTADO DE CIENTÍFICOS POR ÁREA---------------------------")
        print("-----------------------------------------------------------------------------------------------------")
        print("ID    Nombre           Ap. Paterno      Ap. Materno      Teléfono    Correo                          ") 
        print("-----------------------------------------------------------------------------------------------------")
          #12345 123456789012345  123456789012345  123456789012345  1234567890  123456789012345678901234567890  
        for reg in lista:
            print(reg[0]+" "+reg[1]+espa(17,reg[1])+reg[2]+espa(17,reg[2])+reg[3]+espa(17,reg[3])+reg[4]+espa(12,reg[4])+reg[5]+espa(32,reg[5]))
        my.error("")
        cone_bd.close()

def lista_proyectos_cientificos():
    desc = 3
    my.limpia_pantalla()
    valida_num()
    query="SELECT * FROM cientificos WHERE id_ci='"+vnum+"'"
    cone_bd=my.conectar_bd()
    cursor=cone_bd.cursor()
    x=cursor.execute(query)
    if x==0:
        my.error("Error, ID inexistente en archivo de científicos...")
    else:
        datos_area=cursor.fetchone()
        #print(" "*60,"ID del científico : ",datos_area[0])
        query="SELECT id_pro, nombre_pro, area_pro, descripcion_pro, id_ci"
        query+=" FROM cientificos, proyectos"
        query+=" WHERE id_ci='"+vnum+"' and id_ci=id_ci_pro"
        cursor.execute(query)
        lista=cursor.fetchall()
        n = 40
        for reg in lista:
            print("ID del proyecto: {} ||| Nombre: {} ||| Área: {} ||| Id Científico: {}".format(reg[0], reg[1], reg[2], reg[4]))
            #print("Descripcion: {}".format(reg[desc]))
            print("Descripcion:")
            chunks = [reg[desc][i:i+n] for i in range(0, len(reg[desc]), n)]
            #print(chunks)
            for ndesc in chunks:
                print('{:^40}'.format(ndesc))
            print("---------------------------------------------------------------------------------------------------------------------------")
            #print(reg[0]+" "+reg[1]+espa(17,reg[1])+reg[2]+espa(17,reg[2])+reg[3]+espa(42,reg[3])+reg[4]+espa(12,reg[4]))
        my.error("")
        cone_bd.close()
        print(reg)


def modulo_reportes():
    op=-1
    while op!=0:
        my.limpia_pantalla()
        print("|--------------------------------------------------|")
        print("| MENU DE PROYECTO                                 |")
        print("|--------------------------------------------------|")
        print("| 1) Listas de cientifícos                         |")
        print("| 2) Lista  de proyectos                           |")
        print("| 3) Lista de proyectos por área                   |")
        print("| 4) Lista de científicos por área                 |")
        print("| 5) Lista de proyectos asignados a un científico  |")
        print("| 0) Regresar al menú principal                    |")
        print("|--------------------------------------------------|")
        op=my.pide_entero(0,5,"Indica la opción deseada: ")
        if op==1:
            lista_cientificos()
        if op==2:
            lista_proyectos()
        if op==3:
            lista_proyectos_area()
        if op==4:
            lista_cientificos_area()
        if op==5:
            lista_proyectos_cientificos()
        my.limpia_pantalla()
